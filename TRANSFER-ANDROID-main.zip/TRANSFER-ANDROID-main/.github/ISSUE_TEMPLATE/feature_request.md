---
name: Feature request
about: Suggest an idea
title: ''
labels: ''
assignees: ''

---

**Feature Description**  
A short description of the feature you’re requesting.

**Why is this feature needed?**  
Explain the problem this feature would solve or the value it would add.

**Additional context**  
Add any other context that can help explain your request.
